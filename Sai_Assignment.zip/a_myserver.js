var express = require("express");
var bodyParser = require("body-parser");
var routes = require('./a_routes');
var app = express();

app.use(bodyParser.urlencoded({ extended: true }));

app.use('/',express.static('public'));
app.use('/',routes); 

app.listen(80);
console.log("Server Started at Port 80");
