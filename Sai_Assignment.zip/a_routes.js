var express = require("express");
var router = express.Router();
const { con } = require("./a_dbutil");

router.get("/", function (req, res) {
  res.sendFile(__dirname + "/a_registrationpage.html");
});

router.get("/verify/:userid", function (req, res) {
  var userid = req.params.userid;
  sql = "select * from register where userid = ?";
  con.query(sql, [userid], function (err, result) {
    var json = JSON.parse(JSON.stringify(result));
    if (json.length == 0) {
      res.send(userid + ",1");
    } else {
      res.send(userid + ",0");
    }
  });
});

router.post("/register", function (req, res) {
  userid = req.body.userid;
  password = req.body.password;
  sql = "insert into register values(?,?)";
  con.query(sql, [userid, password], function (err, result) {
    console.log(result);
    res.sendFile(__dirname + "/a_loginpage.html");
  });
});

router.get("/login/:userid/:password", function (req, res) {
  userid = req.params.userid;
  password = req.params.password;
  sql = "select * from register where userid = ?";
  con.query(sql, [userid], function (err, result) {
    var json = JSON.parse(JSON.stringify(result));
    if (json.length == 0) {
      res.send("UserId Does Not Exist");
    } else {
      if (json[0].userid == userid && json[0].password == password) {
        res.send("Account Verified");
      } else {
        res.send("Account Not Verified");
      }
    }
  });
});

module.exports = router;
